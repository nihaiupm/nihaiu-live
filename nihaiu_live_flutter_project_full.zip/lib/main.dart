import 'package:flutter/material.dart';
import 'lib/screens/home_screen.dart';

void main() {
  runApp(NihaiuLiveApp());
}

class NihaiuLiveApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Nihaiu Live',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: HomeScreen(),
    );
  }
}
